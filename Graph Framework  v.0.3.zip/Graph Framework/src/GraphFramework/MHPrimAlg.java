
package GraphFramework;

import GraphFramework.Graph;
import java.util.LinkedList;
public class MHPrimAlg extends MSTAlgorithm {
    
    int cost;
    
    public MHPrimAlg(Graph gragh){
        super(gragh);
    }
    
    //prim implementation
    public void mhPrim() {
    
    }
    public int getCost() {
        return cost;
    }
    
    public void displayResultingMST (LinkedList<Edge> edgeList){
        super.displayResultingMST();
    }
    
}
