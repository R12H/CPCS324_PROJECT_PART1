
package GraphFramework;

public class MHPrimAlg extends MSTAlgorithm {
    
    public void displayResultingMST (){
        
    }
    
}
