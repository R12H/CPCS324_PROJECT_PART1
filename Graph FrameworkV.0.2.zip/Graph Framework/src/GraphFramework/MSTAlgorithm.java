
package GraphFramework;

import java.util.*;

public class MSTAlgorithm {
    
    LinkedList<Edge> MSTResultList;
    
    public void displayResultingMST (){
        
    }
}
