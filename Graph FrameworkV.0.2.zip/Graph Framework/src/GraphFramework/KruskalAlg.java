
package GraphFramework;

/**
 *
 * @author WED
 */
public class KruskalAlg extends MSTAlgorithm {
    
    public void displayResultingMST (){
        
    }
    
}
