/* Team members:
Raghad Hawsawi 2105869 - Najd Khalid 2006156 - Wed Aljahdali 2105502 - Renad Baghdadi 2006538

Resources
1)  /https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-in-java-using-priorityqueue

Section:
CP1
 */
package AirFreightApp;

import GraphFramework.*;

public class Location extends Vertex{
    
    String city;
    
    public Location(String label) {
        super(label);
    }
    
    @Override
    public void displayInfo() {
        System.out.print(super.getLabel()+ "; city");
    }
    
}
