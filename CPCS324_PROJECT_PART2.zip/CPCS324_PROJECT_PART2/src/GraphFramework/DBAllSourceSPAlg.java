/* Team members:
Raghad Hawsawi 2105869 - Najd Khalid 2006156 - Wed Aljahdali 2105502 - Renad Baghdadi 2006538

Resources
1)  /https://www.geeksforgeeks.org/dijkstras-shortest-path-algorithm-in-java-using-priorityqueue

Section:
CP1
 */
package GraphFramework;

public class DBAllSourceSPAlg extends ShortestPathAlgorithm {

    public DBAllSourceSPAlg(Graph graph) {
        super(graph);
    }

    public void computeDijkstraBasedSPAlg() throws CloneNotSupportedException {
        
        SingleSourceSPAlg dijkstraOneSourse = new SingleSourceSPAlg(super.gragh);
        
        for (int i = 0; i < super.gragh.verticesNo; i++) {

            dijkstraOneSourse.computeDijkstraAlg(super.gragh.vertices.get(i));

            System.out.println("    The starting point location is " + super.gragh.vertices.get(i).getLabel());

            dijkstraOneSourse.displayResultingMST();
            System.out.println();
            
            System.out.println("    ---------------------------\n");

        }

    }
}
