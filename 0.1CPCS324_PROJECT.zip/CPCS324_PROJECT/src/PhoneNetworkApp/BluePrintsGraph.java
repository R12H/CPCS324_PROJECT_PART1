
package PhoneNetworkApp;

import GraphFramework.*;
import java.io.*;

public class BluePrintsGraph extends Graph {
    
    public BluePrintsGraph(){
        super();
    }

    public BluePrintsGraph(int vertices, int edges, boolean isDigraph) {
       super(vertices, edges, isDigraph);
    }

    //----------------------------------------------------------------------------------
    
    @Override
    public void makeGraph(int reqVetices, int reqEdges) {
        super.makeGraph(reqVetices, reqEdges);
    }
    
    @Override
    public void readGraphFromFile(File file) throws FileNotFoundException {
       super.readGraphFromFile(file);

    }
    //-----\
    /**
    public int getCost() {
        return super.getCost() * 5;
    }*/
    
    @Override
    public Vertex createVertex(String label){
        return new Office(label);
    }
    
    @Override
    public Edge createEdge(Vertex source, Vertex destination, int weight) {
        return new Line(source, destination, weight);
    }
    
}
