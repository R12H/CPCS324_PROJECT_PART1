
package PhoneNetworkApp;

import GraphFramework.*;
import java.io.*;

public class BluePrintsGraph extends Graph {
    
    public int labelNo = 0;
    
    public BluePrintsGraph(){
        super();
    }

    public BluePrintsGraph(int vertices, int edges, boolean isDigraph) {
       super(vertices, edges, isDigraph);
    }

    //----------------------------------------------------------------------------------
    
    @Override
    public void makeGraph(int reqVetices, int reqEdges) {
        super.makeGraph(reqVetices, reqEdges);
    }
    
    @Override
    public void readGraphFromFile(File file) throws FileNotFoundException {
       super.readGraphFromFile(file);

    }
    
    //----------------------------------------------------------------------------------
    
    @Override
    public Vertex createVertex(String label){
        if ( label.equals("Random"))
            return new Office("O" + ++labelNo);
        return new Office(label);
    }
    
    @Override
    public Edge createEdge(Vertex source, Vertex destination, int weight) {
        return new Line(source, destination, weight);
    }
    
}
