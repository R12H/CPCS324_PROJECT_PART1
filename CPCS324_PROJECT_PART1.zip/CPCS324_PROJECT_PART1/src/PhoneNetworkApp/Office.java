
package PhoneNetworkApp;

import GraphFramework.*;

public class Office extends Vertex {
    
   private String label;
    
    public Office(){ 
        super();
    }
    
    //----------------------------------------------------------------------------------
    public Office(String label) {
        super(label);
    }
    
    //----------------------------------------------------------------------------------
    public void setLabel(String label) {
        this.label = ("O" +  label);
    }
    
    //----------------------------------------------------------------------------------
    @Override
    public void displayInfo() {
            System.out.print("Offic No. " + super.getLabel());

    }
}
