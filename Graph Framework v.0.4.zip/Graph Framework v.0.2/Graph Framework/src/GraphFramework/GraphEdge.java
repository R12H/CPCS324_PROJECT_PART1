package GraphFramework;

public class GraphEdge extends Edge {
    public GraphEdge(Vertex source, Vertex target, int weight) {
        super(source, target, weight);
    }

    public GraphEdge(Vertex parent, Vertex source, Vertex target, int weight) {
        super(parent, source, target, weight);
    }

    public void displayInfo() {
        System.out.println("Edge from " + source.getLabel() + " to " + target.getLabel() + " with weight " + weight);
    }
}
